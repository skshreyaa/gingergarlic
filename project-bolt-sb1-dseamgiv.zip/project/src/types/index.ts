export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  contactNumber: string;
  condition: string;
  priority: 'Low' | 'Medium' | 'High';
  registrationTime: string;
}
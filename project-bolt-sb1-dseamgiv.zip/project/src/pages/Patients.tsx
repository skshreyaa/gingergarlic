import React from 'react';
import { PatientForm } from '../components/PatientForm';
import { WaitingList } from '../components/WaitingList';
import { useState } from 'react';
import { Patient } from '../types';

export function Patients() {
  const [patients, setPatients] = useState<Patient[]>([]);

  const handleAddPatient = (patient: Patient) => {
    setPatients([...patients, patient]);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="lg:sticky lg:top-8">
          <PatientForm onAddPatient={handleAddPatient} />
        </div>
        <div>
          <WaitingList patients={patients} />
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Activity, Users, Clock, AlertTriangle } from 'lucide-react';

export function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { title: 'Total Patients', value: '1,284', icon: Users, color: 'from-blue-600 to-blue-400' },
          { title: 'Waiting Time', value: '18 mins', icon: Clock, color: 'from-emerald-600 to-emerald-400' },
          { title: 'Active Cases', value: '48', icon: Activity, color: 'from-violet-600 to-violet-400' },
          { title: 'Critical Cases', value: '6', icon: AlertTriangle, color: 'from-red-600 to-red-400' },
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <div className={`flex items-center justify-center p-3 rounded-lg bg-gradient-to-r ${stat.color}`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                    <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
                  </div>
                </div>
              </div>
              <div className={`px-6 py-2 bg-gradient-to-r ${stat.color} bg-opacity-10`}>
                <div className="text-sm text-gray-600">
                  <span className="font-medium text-green-600">↑ 12%</span> vs last month
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Patients</h2>
          <div className="space-y-4">
            {[
              { name: 'John Doe', time: '10:30 AM', condition: 'Fever', priority: 'High' },
              { name: 'Jane Smith', time: '11:15 AM', condition: 'Check-up', priority: 'Low' },
              { name: 'Mike Johnson', time: '11:45 AM', condition: 'Injury', priority: 'Medium' },
            ].map((patient, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-600 to-blue-400 flex items-center justify-center text-white font-semibold">
                      {patient.name.split(' ').map(n => n[0]).join('')}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{patient.name}</p>
                    <p className="text-sm text-gray-500">{patient.condition}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-900">{patient.time}</p>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    patient.priority === 'High' ? 'bg-red-100 text-red-800' :
                    patient.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {patient.priority}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Department Status</h2>
          <div className="space-y-4">
            {[
              { name: 'Emergency Room', capacity: 80, color: 'red' },
              { name: 'General Ward', capacity: 65, color: 'blue' },
              { name: 'ICU', capacity: 45, color: 'yellow' },
              { name: 'Pediatrics', capacity: 30, color: 'green' },
            ].map((dept, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-600">{dept.name}</span>
                  <span className="text-sm font-medium text-gray-900">{dept.capacity}%</span>
                </div>
                <div className="overflow-hidden h-2 rounded bg-gray-100">
                  <div
                    className={`h-full rounded bg-${dept.color}-500 transition-all duration-500`}
                    style={{ width: `${dept.capacity}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
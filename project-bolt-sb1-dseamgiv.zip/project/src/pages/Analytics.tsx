import React from 'react';
import { BarChart, Activity, TrendingUp } from 'lucide-react';

export function Analytics() {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Patient Analytics</h2>
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium">Daily</button>
            <button className="px-4 py-2 text-gray-600 rounded-lg text-sm font-medium">Weekly</button>
            <button className="px-4 py-2 text-gray-600 rounded-lg text-sm font-medium">Monthly</button>
          </div>
        </div>
        
        <div className="h-80 flex items-end justify-between space-x-2">
          {[40, 25, 35, 45, 35, 55, 45].map((height, index) => (
            <div key={index} className="w-full">
              <div
                className="bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-lg transition-all duration-300 hover:from-blue-700 hover:to-blue-500"
                style={{ height: `${height}%` }}
              />
              <div className="text-center mt-2 text-sm text-gray-600">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][index]}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Department Performance</h2>
          <div className="space-y-4">
            {[
              { name: 'Emergency', value: '94%', trend: '+5.25%' },
              { name: 'Outpatient', value: '89%', trend: '+3.15%' },
              { name: 'Radiology', value: '92%', trend: '+4.75%' },
              { name: 'Laboratory', value: '87%', trend: '+2.98%' },
            ].map((dept, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="h-10 w-10 rounded-lg bg-gradient-to-r from-blue-600 to-blue-400 flex items-center justify-center">
                    <Activity className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{dept.name}</p>
                    <p className="text-xs text-gray-500">Performance Score</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-gray-900">{dept.value}</p>
                  <p className="text-xs text-green-600">{dept.trend}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Patient Satisfaction</h2>
          <div className="relative pt-1">
            {[
              { label: 'Very Satisfied', percentage: 68, color: 'emerald' },
              { label: 'Satisfied', percentage: 24, color: 'blue' },
              { label: 'Neutral', percentage: 5, color: 'yellow' },
              { label: 'Unsatisfied', percentage: 3, color: 'red' },
            ].map((item, index) => (
              <div key={index} className="mb-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                  <span className="text-sm font-medium text-gray-700">{item.percentage}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full bg-${item.color}-500`}
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
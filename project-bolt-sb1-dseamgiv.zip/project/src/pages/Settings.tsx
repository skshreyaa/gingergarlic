import React from 'react';
import { Settings2, Bell, Shield, User, Database } from 'lucide-react';

export function Settings() {
  const settingsSections = [
    {
      title: 'Profile Settings',
      icon: User,
      items: [
        { label: 'Update Profile Information', description: 'Manage your account details and preferences' },
        { label: 'Change Password', description: 'Update your password and security settings' },
        { label: 'Two-Factor Authentication', description: 'Add an extra layer of security to your account' },
      ]
    },
    {
      title: 'Notifications',
      icon: Bell,
      items: [
        { label: 'Email Notifications', description: 'Manage email alert preferences' },
        { label: 'System Alerts', description: 'Configure system notification settings' },
        { label: 'Patient Updates', description: 'Set patient-related notification preferences' },
      ]
    },
    {
      title: 'Privacy & Security',
      icon: Shield,
      items: [
        { label: 'Data Privacy', description: 'Manage your data sharing preferences' },
        { label: 'Access Logs', description: 'View recent account activity' },
        { label: 'Security Settings', description: 'Configure security preferences' },
      ]
    },
    {
      title: 'System Settings',
      icon: Settings2,
      items: [
        { label: 'General Settings', description: 'Configure general system preferences' },
        { label: 'Backup & Restore', description: 'Manage system backup settings' },
        { label: 'Integration Settings', description: 'Configure third-party integrations' },
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {settingsSections.map((section, index) => {
        const Icon = section.icon;
        return (
          <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Icon className="h-6 w-6 text-blue-600" />
                </div>
                <h2 className="text-lg font-semibold text-gray-900">{section.title}</h2>
              </div>
              <div className="space-y-4">
                {section.items.map((item, itemIndex) => (
                  <div
                    key={itemIndex}
                    className="flex items-center justify-between p-4 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                  >
                    <div>
                      <h3 className="text-sm font-medium text-gray-900">{item.label}</h3>
                      <p className="text-sm text-gray-500">{item.description}</p>
                    </div>
                    <button className="p-2 hover:bg-blue-50 rounded-lg transition-colors">
                      <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}